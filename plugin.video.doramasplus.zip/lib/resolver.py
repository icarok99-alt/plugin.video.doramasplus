import xbmc
import time

class Resolver:
    def __init__(self):
        self.ensure_resolveurl()

    def ensure_resolveurl(self):
        try:
            import resolveurl
        except ImportError:
            try:
                xbmc.executebuiltin("UpdateLocalAddons()")
                xbmc.executebuiltin("UpdateAddonRepos()")
                xbmc.executebuiltin('InstallAddon(script.module.resolveurl.fork)')
                xbmc.executebuiltin('SendClick(11)')
                time.sleep(7)
            except:
                xbmc.log("[Resolver] Erro ao instalar resolveurl", xbmc.LOGERROR)

    def resolverurls(self, url, referer=None):
        try:
            import resolveurl

            if not resolveurl.HostedMediaFile(url):
                xbmc.log(f"[Resolver] URL não suportada: {url}", xbmc.LOGWARNING)
                return None, None

            stream_url = resolveurl.resolve(url)

            if stream_url:
                xbmc.log(f"[Resolver] URL resolvida com sucesso: {url[:50]}...", xbmc.LOGINFO)
                return stream_url, None
            else:
                xbmc.log(f"[Resolver] Falha ao resolver URL: {url}", xbmc.LOGWARNING)
                return None, None

        except ImportError:
            xbmc.log("[Resolver] Módulo resolveurl não encontrado", xbmc.LOGERROR)

            time.sleep(2)
            try:
                import resolveurl
                if resolveurl.HostedMediaFile(url):
                    stream_url = resolveurl.resolve(url)
                    if stream_url:
                        return stream_url, None
            except:
                pass

            return None, None

        except Exception as e:
            xbmc.log(f"[Resolver] Erro ao resolver URL: {str(e)}", xbmc.LOGERROR)
            return None, None
